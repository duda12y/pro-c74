import * as React from 'react';
import { Text, View, StyleSheet, Image} from 'react-native';


export default class App extends React.Component {
   
   constructor(){
     super();
     this.state= {
       api: ''
     }
   }
   
   componentDidMount(){
     this.pegarDados()
   }
  pegarDados=async()=>{

    var link = 'https://api.openweathermap.org/data/2.5/weather?q=Cuiaba&units=metric&APPID=143454aa39bbe3442a890cdbf3f9db36'

    return fetch(link)
    .then(resposta => resposta.json ())
    .then(respostaJson => {
      this.setState({ api : respostaJson})
    })
    .catch( erro => console.error(erro))
  }




  render(){
   if(this.state.api == ''){
     return(  
    <View style={styles.container}>
    <View style={styles.subContainer}>
      <Text style={styles.title}>

        Carregando 
      </Text> 
      
    </View>

    </View>
   );










   }else{

   return (
    
    <View style={styles.container}>
    <View style={styles.subContainer}>
      <Text style={styles.title}>
        Previsão do Tempo
      </Text> 
      
       
       <Text> cidade: { this.state.api.name}</Text>
      <Text> temperatura:{this.state.api.main.temp} ºC </Text>
      <Text> tempo:{this.state.api.weather[0].main} </Text>
    </View>

    </View>
   );


   }





  return (
    
    <View style={styles.container}>
    <View style={styles.subContainer}>
      <Text style={styles.title}>
        Previsão do Tempo
      </Text> 
      
    </View>

    </View>
   );

}
}


const styles = StyleSheet.create({
 container: {
   flex:1
  },
  subContainer : { 
    flex: 1, 
    borderWidth: 1, 
    alignItems: 'center' 
    },
    title:{ 
      marginTop: 50, 
      fontSize: 30,
      fontWeight: 'bold' 
    },
    imagem :{ 
      width: 150, 
      height: 150, 
      marginTop: 30 
    },
    textContainer : { 
      flex: 1,
      width:'100%',

    },
    texto:{      
      marginHorizontal:20,
      fontSize:20,
      textAlign:'left'
    }
});
